let Y = document.querySelector("#Y");
let X = document.querySelector("#X") ;
let Z = document.querySelector("#Z");
let botao = document.querySelector("#botao");
let resultado = document.querySelector("#resultado");



function calcular() {
    let Y1 = Number(Y.value);
    let X1 = Number(X.value);
    let Z1 = Number(Z.value);

    if (X1 < Y1 + Z1 && Y1 < X1 + Z1 && Z1 < X1 + Y1) {
        if (Y1 == X1 && X1 == Z1) {
            resultado.textContent = "Equilátero: tem os comprimentos dos três lados iguais.";
        } else if (Y1 == X1 || X1 == Z1 || Y1 == Z1) {
            resultado.textContent = "Isósceles: tem os comprimentos de dois lados iguais.";
        } else {
            resultado.textContent = "Escaleno: tem os comprimentos de três lados diferentes.";
        }
    } else {
        resultado.textContent = "Os valores inseridos não formam um triângulo.";
    }
}


botao.onclick = function (){
    calcular();
};






//exercicio 2 


let altura = document.querySelector("#altura");
let peso = document.querySelector("#peso");
let botao2 = document.querySelector("#botao2");
let resultado2 = document.querySelector("#resultado2");


function calcularimc (){
    let alt = Number(altura.value);
    let ps = Number(peso.value);
    let imc = ps/(alt * alt);
    let classificacao = '';
    
    if(imc< 18.5){
classificacao = "abaixo do peso";
    }
    else if ( imc<25){
        classificacao = "peso normal";
    }
else if ( imc<30){
    classificacao = "sobre peso";
}
else if (imc<35){
    classificacao =  "obesidade grau 1";
}
else if (imc<40){
    classificacao = "obesidade grau 2";
}
else{
    classificacao = "obesidade grau 3";
}
resultado2.textContent = imc.toFixed(2) + " : "+
 classificacao;


}
botao2.onclick = function(){
    calcularimc();
};








//exercicio 3

let ano = document.querySelector("#ano");
let tabela = document.querySelector("#tabela");
let botao3 = document.querySelector("#botao3");
let resultado3 = document.querySelector("#resultado3");

function calcularano() { 
    let valor1 = Number(ano.value);
    let tabela1 = Number(tabela.value);
    let imposto = 0;

    if (valor1 < 1990 ) {
        imposto = tabela1 * 0.01;

    } else  {
        imposto = tabela1 * 0.015;
    }


resultado3.innerHTML = "<h3> o imposto a ser pago é: R$" + imposto + "</h3>" 
}   

botao3.onclick = function () {
    calcularano();
}





//exercicio 4

let salario = document.querySelector("#salario");
let cargo = document.querySelector("#cargo");
let botao4 = document.querySelector("#botao4");
let resultado4 = document.querySelector("#resultado4");


function aumento() { 
    let salario1 = Number(salario.value);
    let cargo1 = cargo.value.toLowerCase();
    let aumento = 0;

if (cargo1 =="gerente") {
    aumento = 0.10; }

    else if  (cargo1 =="engenheiro") { 
    aumento = 0.20;

    }

   else if (cargo1 == "tecnico") {
    aumento = 0.30; }

  else {
    aumento = 0.40; 
  }

  let valoraumento = salario1 * aumento;
  let novosalario = salario1 + valoraumento;


resultado4.innerHTML = "<h3> o salario antigo é: " + salario1 +  "<br>" +
                    "o novo salario é: " + novosalario +  "<br>" +
                    "a diferenca é de: " + valoraumento +  "</h3>";

   
}





botao4.onclick = function () {
    aumento();
}





//exercicio 5

let saldo = document.querySelector("#saldo");
let botao5 = document.querySelector("#botao5");
let resultado5 = document.querySelector("#resultado5");


function calcularsaldo(){

    let sld = Number(saldo.value);
    let credito
    let vlrsaldo = sld / 12;

    if(vlrsaldo<=200){
        credito = 0;
    }
    else if(vlrsaldo<=400){
        credito = vlrsaldo * 0.2;
    }
    else if(vlrsaldo<=600){
        credito = vlrsaldo * 0.3
    }
    else{
        credito = vlrsaldo * 0.4;
    }
    resultado5.innerHTML = "saldo medio R$ "+ vlrsaldo.toFixed(2) + "<br> credito concedido: R$ " + credito.toFixed(2);
}
botao5.onclick = function(){
    calcularsaldo();
};






//exercicio 6

let produto = document.querySelector("#produto");
let quantidade = document.querySelector("#quantidade");
let botao6 = document.querySelector("#botao6");
let resultado6 = document.querySelector("#resultado6");

function verificar() {
    let item = (produto.value);
    let qtd = Number(quantidade.value);
    let preco = 0;


    if (item=== "cachorro quente") {
        preco = 11;
    } else if (item=== "bauru") {
        preco = 8.50;
    } else if (item=== "mistoquente") {
        preco = 8;
    } else if (item=== "hamburger") {
        preco =9;
    } else if (item=== "cheeseburger") {
        preco =10;
    } else if (item=== "refrigerante") 
        preco =4.50;

    let total = preco * qtd; 

    resultado6.innerHTML = "Item :" + item + "<br> Quantidade :" + qtd 
                           + "<br> Total a Pagar : " + total ; 
        

     

    

}
 
botao6.onclick = function() {
    verificar();
}







//exercicio 7

let selectProduto = document.querySelector("#valor");
let desconto = document.querySelector("#desconto");
let botao7 = document.querySelector("#botao7");
let resultado7 = document.querySelector("#resultado7");

function porcentagem() {
    let valor1 = Number(selectProduto.options[selectProduto.selectedIndex].dataset.valor);
    let desconto1 = desconto.value;
    let total = 0;
    let mensagem = "";

    if (desconto1 === "avistacheque") {
        total = valor1 * 0.9;
        mensagem = "Desconto à vista no cheque.";
    } 
    else if (desconto1 === "avistacartao") {
        total = valor1 * 0.85;
        mensagem = "Desconto à vista no cartão.";
    } 
    else if (desconto1 === "2xsj") {
        total = valor1;
        mensagem = "Pagamento em 2x sem juros.";
    } 
    else if (desconto1 === "2xcj10") {
        total = valor1 * 1.10;
        mensagem = "Pagamento em 2x com juros de 10%.";
    }

    resultado7.innerHTML = "<h3>" + mensagem + " Total a pagar: R$ " + total.toFixed(2) + "</h3>";
}


botao7.onclick = function() { 
    porcentagem();
};










//exercicio 8 

let nivel = document.querySelector("#nivel");
let aulas = document.querySelector("#aulas");
let botao8 = document.querySelector("#botao8");
let resultado8 = document.querySelector("#resultado8");


function salarioprofessor(){

    let nvl = Number(nivel.value);
    let aul = Number(aulas.value);
    let valorhora;

    if( nvl === 1){
valorhora =12;
    }

    else if( nvl ===2)
    {valorhora = 17;}

    else{
        valorhora = 25;
    }
    let salario = (valorhora * aul) * 4.5;

    resultado8.innerHTML = "nivel: " + nvl + "<br> aulas : "+ aul +"<br> salario R$:"+ salario;
}
botao8.onclick = function(){
    salarioprofessor();
};

