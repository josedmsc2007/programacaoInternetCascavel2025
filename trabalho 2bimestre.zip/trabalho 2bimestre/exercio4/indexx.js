let salario = document.querySelector("#salario");
let cargo = document.querySelector("#cargo");
let botao4 = document.querySelector("#botao4");
let resultado4 = document.querySelector("#resultado4");


function aumento() { 
    let salario1 = Number(salario.value);
    let cargo1 = cargo.value.toLowerCase();
    let aumento = 0;

if (cargo1 =="gerente") {
    aumento = 0.10; }

    else if  (cargo1 =="engenheiro") { 
    aumento = 0.020;

    }

   else if (cargo1 == "tecnico") {
    aumento = 0.30; }

  else {
    aumento = 0.40; 
  }

  let valoraumento = salario1 * aumento;
  let novosalario = salario1 + aumento;


resultado4.innerHTML = "<h2> o salario antigo é: " + salario1 +  "<br>" +
                    "o novo salario é: " + novosalario +  "<br>" +
                    "a diferenca é de: " + valoraumento +  "</h2>";

   
}





botao4.onclick = function () {
    aumento();
}




