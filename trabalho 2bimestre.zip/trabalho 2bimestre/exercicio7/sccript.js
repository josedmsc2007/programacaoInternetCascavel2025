let valor = document.querySelector("#valor");
let botao7 = document.querySelector("#botao7");
let desconto = document.querySelector("#desconto");
let resultado7 = document.querySelector("#resultado7");



function porcentagem() {
    let valor1 = Number(valor.value);
    let desconto1 = desconto.value;
    let total = 0; 
    


if (desconto1 === "avistacheque") {
    total = valor1 * 0.1; } 

else if (desconto1 === "avistacartao") {
    total = valor1 *  0.15; }

else if (desconto1 === "2xsj") {
    total = valor1   / 2 ; }

else if (desconto1 === "2xcj10") {
    total = (valor1  * 0.10) / 2; 
}


resultado7.innerHTML = "<h3> resultado: " + total + "</h3>"

}

botao7.onclick = function() { 
    porcentagem();
}