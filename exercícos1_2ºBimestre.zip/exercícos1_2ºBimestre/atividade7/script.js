let valor1 = document.querySelector("#valor1");
let btAprovacao = document.querySelector("#btAprovacao");
let resultado = document.querySelector("#resultado");

function maiorValor() {
    let numero1 = Number(valor1.value);

//mostrar o maior valor
if(numero1 % 2){
    resultado.textContent = "O número e inpar "  + numero1;
}else{
    resultado.textContent = "O número e par " + numero1;
};

}

btAprovacao.onclick = function() {
    maiorValor();
}