let pago = document.querySelector("#pago");
let valor = document.querySelector("#valor");
let btcalcular = document.querySelector("#btcalcular");
let resultado = document.querySelector("#troco");

function calcular(){
    let numeropago = Number (pago.value);
    let numerovalor = Number (valor.value);
    let troco = numeropago * numerovalor;
    resultado.textContent ="troco:" + troco;
}
btcalcular.onclick = function(){
calcular();
}