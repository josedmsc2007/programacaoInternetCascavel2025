let soma1 = document.querySelector("#soma1");
let soma2 = document.querySelector("#soma2");
let btsoma = document.querySelector("#somar");
let resultado = document.querySelector("#resultado");

function somar(){
    let numero1somado = Number (soma1.value);
    let numero2somado = Number(soma2.value);
    let resultadosoma = numero1somado + numero2somado;
    resultado.textContent = resultadosoma;
}
btsoma.onclick = function(){
    somar();
}



