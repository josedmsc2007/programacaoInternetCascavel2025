let saldo = document.querySelector("#saldo");
let porcentagem = document.querySelector("#porcentagem");
let calcular = document.querySelector("#calcular");
let reajuste = document.querySelector("#ajuste");

function calreajuste(){
    let saldoo = Number(saldo.value);
    let porcentagemm = Number(porcentagem.value);
    let total = saldoo +(saldoo * (porcentagemm / 100));
    reajuste.textContent= "reajuste " + total.toFixed(2);

}

calcular.onclick = function(){    
    calreajuste();

}
